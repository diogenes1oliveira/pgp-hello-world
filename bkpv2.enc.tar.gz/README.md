# cine-holliu

A drugless trip through the Fundamentals of Prompt Engineering.

## Quick Start

1. Install dependencies: `uv sync`
2. Serve documentation: `just dev`
3. Build documentation: `just build`
4. Convert markdowns to HTML + YAML: `just md2html`

## Documentation

- [Home](docs/index.md)

## GitHub Pages

> **Note for new developers:** To enable the GitHub Pages deployment, go to
> **Settings → Pages** in this repository and set the source to
> **"GitHub Actions"**. The `deploy.yml` workflow will handle the rest.
